package exercicio4Processador;

import filas.FilaInt;

import java.util.Scanner;

public class Processador {
    public static void main(String[] args) {
        Scanner le = new Scanner(System.in);
        FilaInt fila = new FilaInt();
        fila.init();
        int opcao;
        do {
            System.out.println("1-  Insere processo na fila");
            System.out.println("2-  Excuta processo ");
            System.out.println("3-  Shutdown");
            opcao = le.nextInt();
            switch (opcao) {
                case 1:
                    System.out.print("Informe pid do processo que está sendo submetido: ");
                    int pid = le.nextInt();
                    fila.enqueue(pid);
                    break;
                case 2:
                    if (fila.isEmpty()) {
                        System.out.println("Não há processos na fila");
                    } else {
                        pid = fila.dequeue();
                        System.out.println("Processo: " + pid + " será executado agora");
                        System.out.println("... Execução...");
                        System.out.print("O Processo concluiu? (1- sim): ");
                        int resp = le.nextInt();
                        if (resp == 1) {
                            System.out.println("O processo " + pid + " foi concluído");
                        } else {
                            System.out.println("Processo voltou para fila");
                            fila.enqueue(pid);
                        }
                    }
                    break;
                case 3:
                    if (!fila.isEmpty()) {
                        System.out.println("Ainda há processos em execução (Fila não está vazia)");
                        System.out.print("Quer encerrar todos? (1-sim): ");
                        int resp = le.nextInt();
                        if (resp == 1) {
                            while (!fila.isEmpty()) {
                                System.out.println("Processo " + fila.dequeue() + " foi encerrado");
                            }
                        } else {
                            opcao = 0;
                        }
                    }
                    break;
                default:
                    System.out.println("Opção inválida");
            }
        }
        while (opcao != 3);
        System.out.println("Shutdown ...");
    }
}
